// Assignment 4           Lab4Function1.cpp         Your Name Here
//
//  refer to Lab4Function.doc for instructions on how to complete this lab,
//  and Chapter 5 for in depth coverage of the material.
//  

#include <iostream>
using namespace std;

void opening()
{
    cout<<"Once upon a time, ";
}


int main(  )          // main block where execution begins
{
	
    system("pause");
    return 0;
}

