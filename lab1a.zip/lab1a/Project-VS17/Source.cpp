#include<iostream>
using namespace std;

int main()
{
	int x;
	cout<<"Hello world, what number are you?"<<endl;
	cin>>x;
	cout<<"x = " <<x<<endl;
	system("pause");
	return 0;
}